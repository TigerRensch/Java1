 
 import java.io.BufferedReader;
 import java.io.FileNotFoundException;
 import java.io.FileReader;
 import java.io.IOException;
 import java.util.ArrayList;
 
 public class StudentFileReader
 {
    public ArrayList<Student> readStudentList(String filePath){
    		//Student Array List
    		ArrayList<Student> studentList = new ArrayList<Student>();
    		BufferedReader bufferedReader = null;
    		String line = null;
    		String[] lineArray;
            try {
            	//Read File
                bufferedReader = new BufferedReader(new FileReader(filePath));
                //Loop until the end of the file creating students
                while((line = bufferedReader.readLine()) != null) {
                	lineArray = line.split(",");
                	if(lineArray.length == 2){
                		studentList.add(new Student(lineArray[0], lineArray[1]));
                	}else{
                		System.out.println("Error! There is an error parsing the student list");
                	}
                }   
            }
            catch(FileNotFoundException e) {
            	e.printStackTrace();             
            }
            catch(IOException e) {
            	e.printStackTrace(); 
            }
            finally{
                try {
    				bufferedReader.close();
    			} catch (IOException e) {
    				e.printStackTrace();
    			} 
            }
            return studentList;
    	}
 
 }