//Author: Sachin Haldipur
//Date: 03/24/2017 
//Class Info: CIS163AA - Java Programming: Level I
//Exercise 7
//Description of Program: This program will hold the users 3 initials and display them.

public class Initials
{
   public static void main(String[]args)
   {      
       String firstInitial = "S.";
       String secondInitial = "N.";
       String thirdInitial = "H.";
       
       System.out.println(firstInitial + secondInitial + thirdInitial);

   }
}