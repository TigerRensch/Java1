//Author: Sachin Haldipur
//Date: 04/05/2017 
//Class Info: CIS163AA - Java Programming: Level I
//Lesson 3
//Exercise 12 c 
/*
 *Description of Program: In this program a constructor created in the Student class will be tested by
 *instantiating an object and displaying the initial values.
 */
 
 public class ShowStudent2
 {
     
   public static void main(String[] args)
   {
                            
      Student student1 = new Student();
               
   }
 
 }