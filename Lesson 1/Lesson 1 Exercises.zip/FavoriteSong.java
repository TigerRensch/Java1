public class FavoriteSong
{
   public static void main(String[]args)
   {
      //What Would You Say by Dave Matthews Band
      System.out.println("Up and down the puppies' hair");
      System.out.println("Fleas and ticks jump everywhere");
      System.out.println("Cause of original sin");
      System.out.println("Down the hill fell Jack and Jill");
   }   
}