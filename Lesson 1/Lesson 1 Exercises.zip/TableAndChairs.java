public class TableAndChairs
{
   public static void main(String[]args)
   {
      System.out.println("X" + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + "X");
      System.out.println("X" + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + " " + "X");
      System.out.println("X" + " " + " " + " " + " " + " " + "X" + "X" + "X" + "X" + "X" + "X" + "X" + "X" + "X" + "X" + " " + " " + " " + " " + " " + "X");
      System.out.println("X" + "X" + "X" + "X" + "X" + " " + "X" + " " + " " + " " + " " + " " + " " + " " + " " + "X" + " " + "X" + "X" + "X" + "X" + "X");
      System.out.println("X" + " " + " " + " " + "X" + " " + "X" + " " + " " + " " + " " + " " + " " + " " + " " + "X" + " " + "X" + " " + " " + " " + "X");
      System.out.println("X" + " " + " " + " " + "X" + " " + "X" + " " + " " + " " + " " + " " + " " + " " + " " + "X" + " " + "X" + " " + " " + " " + "X");

   }   
}