import javax.swing.JOptionPane;

public class BurmaShave
{
   public static void main(String[]args)
   {
        //Source: http://burma-shave.org/jingles/1955/dinah_doesnt
  
        JOptionPane.showMessageDialog(null, "Dinah doesn't");
        JOptionPane.showMessageDialog(null, "Treat him right"); 
        JOptionPane.showMessageDialog(null, "But if he'd"); 
        JOptionPane.showMessageDialog(null, "Shave");
        JOptionPane.showMessageDialog(null, "Dyna-mite!");      
   }   
}